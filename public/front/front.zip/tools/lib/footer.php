</div>
<?php include_once('../lib/mobile-menu.php'); ?>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/sticky/sticky.min.js"></script>
<script src="../vendor/parallax/parallax.min.js"></script>
<script src="../vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="../vendor/elevatezoom/jquery.elevatezoom.min.js"></script>
<script src="../vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="../vendor/owl-carousel/owl.carousel.min.js"></script>
<script src="../vendor/nouislider/nouislider.min.js"></script>
<script src="../vendor/photoswipe/photoswipe.min.js"></script>
<script src="../vendor/photoswipe/photoswipe-ui-default.min.js"></script>

<script src="../js/main.min.js"></script>
<script src="assets/js/tools.js"></script>
</body>

</html>